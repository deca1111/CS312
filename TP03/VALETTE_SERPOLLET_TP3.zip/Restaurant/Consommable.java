package Restaurant;

public interface Consommable{

    public String getNom();

    public int getPrix();
    
    public int getKcal();
}
