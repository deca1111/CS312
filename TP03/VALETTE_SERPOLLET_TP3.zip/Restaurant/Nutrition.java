package Restaurant;

public interface Nutrition {    // S'applique à une portion moyenne
	public int getKcal(); 		 // nombre de Kcal 
	public float getGlucides(); // grammes de glucides
}