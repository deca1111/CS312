package Restaurant;

//
public class Dessert extends Plat {
    
    public Dessert(String nom,  int prix, int kcal, float glucides) {
	super(nom,  prix, kcal, glucides);
    }




    
}
