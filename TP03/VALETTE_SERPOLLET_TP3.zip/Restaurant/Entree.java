package Restaurant;



public class Entree extends Plat {
    
    public Entree(String nom, int prix, int kcal, float glucides) {
	super(nom, prix, kcal, glucides);
    }


    
}
