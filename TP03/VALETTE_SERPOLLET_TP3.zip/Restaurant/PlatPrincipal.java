package Restaurant;

public class PlatPrincipal extends Plat {
    public PlatPrincipal(String nom, int prix, int kcal, float glucides) {
	super(nom, prix, kcal, glucides);
    }
}
