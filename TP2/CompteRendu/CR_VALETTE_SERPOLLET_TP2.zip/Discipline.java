public enum Discipline {
	Automatique,
	Informatique,
	Electronique,
	Reseau;
}
